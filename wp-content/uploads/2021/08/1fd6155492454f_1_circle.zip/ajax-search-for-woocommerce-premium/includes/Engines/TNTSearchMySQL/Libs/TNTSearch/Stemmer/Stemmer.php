<?php namespace DgoraWcas\Engines\TNTSearchMySQL\Libs\TNTSearch\Stemmer;

interface Stemmer
{
    public static function stem($word);
}
