<?php

namespace DgoraWcas\Engines\TNTSearchMySQL\SearchQuery;


class SearchResultsPageQuery extends MainQuery {

	public function __construct() {

		parent::__construct();

	}

}
