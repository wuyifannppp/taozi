<?php

namespace DgoraWcas\Engines\TNTSearchMySQL\Libs\TNTSearch\Exceptions;

use Exception;

class IndexNotFoundException extends Exception
{
}
