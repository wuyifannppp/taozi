<?php

use DgoraWcas\Helpers;

// Exit if accessed directly
if ( ! defined( 'DGWT_WCAS_FILE' ) ) {
	exit;
}

?>
<div class="dgwt-wcas-details-inner dgwt-wcas-details-page dgwt-wcas-details-cpt">
	<div class="dgwt-wcas-product-details">

		<a class="dgwt-wcas-pd-details-post" href="<?php echo esc_url( $vars->link ); ?>" title="<?php echo wp_strip_all_tags( $vars->title ); ?>">
			<?php if ( ! empty( $vars->imageSrc ) ): ?>
				<div class="dgwt-wcas-details-main-image">
					<img src="<?php echo esc_url( $vars->imageSrc ); ?>" alt="<?php echo wp_strip_all_tags( $vars->title ); ?>">
				</div>
			<?php endif; ?>
		</a>

		<div class="dgwt-wcas-details-space">
			<a class="dgwt-wcas-details-post-title" href="<?php echo esc_url( $vars->link ); ?>" title="<?php echo wp_strip_all_tags( $vars->title ); ?>">
				<?php echo esc_attr( $vars->title ); ?>
			</a>


			<?php if ( ! empty( $vars->desc ) ): ?>
				<div class="dgwt-wcas-details-desc">
					<?php echo wp_kses_post( $vars->desc ); ?>
				</div>
			<?php endif; ?>

			<div class="dgwt-wcas-details-hr"></div>

			<a class="dgwt-wcas-product-details-readmore" href="<?php echo esc_url( $vars->link ); ?>"><?php echo Helpers::getLabel( 'read_more' ); ?></a>
		</div>

	</div>
</div>

