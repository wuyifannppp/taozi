# -*- coding: UTF-8 -*-
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore

class Config(object):
    # 存储位置
    SCHEDULER_JOBSTORES = {
        'default': SQLAlchemyJobStore(url='sqlite:///ini/rw.db')
    }
    # 线程池配置
    SCHEDULER_EXECUTORS = {
        'default': {'type': 'threadpool', 'max_workers': 1000}
    }
    SCHEDULER_JOB_DEFAULTS = {
        'coalesce': False,
        'max_instances': 1000
    }
    # 调度器控制
    SCHEDULER_API_PW = ''
    # 调度器开关
    SCHEDULER_API_ENABLED = True
    # 后台用户名称
    后台用户名称 = "admin"
    # 后台用户密码
    后台用户密码 = "admin"
    # ----------------------------不用设置区域-开始----------------------------
    # 访问端口 --必填 只允许数字
    访问端口 = 9001
    # 数据库地址
    数据库地址 = ''
    # 数据库端口
    数据库端口 =3306
    # 数据库名称
    数据库名称 = ''
    # 数据库用户
    数据库用户 = ''
    # 数据库密码
    数据库密码 = ''
    # 数据库类型 gbk utf8 utf8mb4
    数据库编码 = ''
    # 数据库前缀
    数据库前缀 = ''
    # 数据库连接池大小
    接池大小 = 30
    系统设置 = {}
    # 一级分类
    一级分类 = []
    # 二级分类
    二级分类 = []
    # 频道
    频道 = []
    # 连载
    连载 = []
    # 标识
    标识 = []
    # 自定内容
    自定内容 = ""
    # UA
    UA = []
    # 代理
    代理 = []
    # 邮件
    邮件 = {}
    # 当前正在任务中的数据
    当前 = []
    # 当前正在任务中的数据
    任务当前 = []
    # ----------------------------不用设置区域-结束----------------------------
